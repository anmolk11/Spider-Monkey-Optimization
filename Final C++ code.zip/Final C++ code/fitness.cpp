#include<bits/stdc++.h>
using namespace std;

int lb[24],ub[24];

void init(){

}



int main(){

}